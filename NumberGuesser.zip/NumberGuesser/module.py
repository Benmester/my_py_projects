from prof import *
from guessnum import *

def Game() -> None:
    Start = input("\n\n\n\n\n\n\n\n\n\nReady? [yes/no]: ")
    if Start == 'yes':
        
        Profile()
        GuessTheNumber()
    else: 
        print(":(")