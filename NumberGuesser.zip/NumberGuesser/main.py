from module import *

# If you press F5 the game will start.
Game()