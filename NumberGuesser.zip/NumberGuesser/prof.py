class Profiles:
    def __init__(self, sor) -> None:
        p:str = sor.strip().split(';')
        self.name:str = str(p[0])
        #self.num_of_games:int = int(p[1])

def Profile():
    ChooseOrCreate:str = str(input('\nWould you like to create a new profile or choose from the existing ones? [new/cho] '))
    if ChooseOrCreate == 'new':
        New:str = str(input('\n\tWhat is your name? '))
        file = open('profiles.txt', 'a', encoding='utf-8')
        file.write(f'\n{New + ';'}')
        print(f"Welcome, {New}!")

    elif ChooseOrCreate == 'cho': 
        profiles:str = []
        file = open('profiles.txt', 'r', encoding='utf-8')
        for line in file:
            profiles.append(Profiles(line))

        for line in profiles:
            print(f'{line.name}', end=', ')
        Choose:str = str(input('\n\tChoose a profile: '))
        for line in profiles:
            if line.name == Choose:
                print(f"Welcome, {Choose}!")
            elif line.name == 'Profiles:':
                continue
            else:
                print("This profile does not exist! Try again!")
                break