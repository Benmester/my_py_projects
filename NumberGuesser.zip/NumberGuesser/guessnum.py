import random

def GuessTheNumber(): 
    print("\n\nThis is a number guessing game. It will generate a number and you have to guess it. The number will always be between 0 and a number you choose. Good luck!\n")
            
    Minimum:int = 0
    Maximum:int = int(input('Maximum: '))
    GeneratedNumber:int = random.randint(Minimum, Maximum)
    Attempt = 0
            
    while True:
        Guess:int = int(input('\nMake your guess: '))
        Attempt += 1
        if Guess < Minimum or Guess > Maximum:
            print(f'\tThis number is out of bounds. Please type somethin between {Minimum} and {Maximum}')
        elif Guess < GeneratedNumber:
            print("\tToo low!")
        elif Guess > GeneratedNumber:
            print("\tToo high!")
        else:
            print(f"\nCongrats! You have guessed it! [{GeneratedNumber}]")
            print(f"Attempts: {Attempt}")
            if Attempt == 1:
                print("You are so lucky! Your have guessed it first try!")
            break